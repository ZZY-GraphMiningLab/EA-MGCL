## EA-MGCL: Encoder Augmention for Multi-task Graph Contrastive Learning 

For example, to run EA-MGCL under Cora, execute:

    python main.py --device cuda:0 --dataset Cora
    
