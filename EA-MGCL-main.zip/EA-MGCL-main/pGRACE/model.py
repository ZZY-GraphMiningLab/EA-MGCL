from typing import Optional

import torch
from torch import nn
import torch.nn.functional as F
import random
import numpy as np
from torch_geometric.nn import GCNConv, GATConv
#from ssgc import Net

from torch.nn import Sequential, Linear, ReLU
from torch_geometric.nn import MessagePassing
from torch_geometric.utils import add_self_loops, degree
from torch_geometric.datasets import TUDataset

import torch
from torch.nn import Parameter
from torch_scatter import scatter_add
from torch_geometric.nn.conv import MessagePassing
from torch_geometric.utils import add_remaining_self_loops
import math
from typing import Optional
from typing import Optional, Tuple, Union

import torch
import torch.nn.functional as F
from torch import Tensor
from torch.nn import Parameter
from torch_sparse import SparseTensor, set_diag

from torch_geometric.nn.dense.linear import Linear
from torch_geometric.typing import (
    Adj,
    NoneType,
    OptPairTensor,
    OptTensor,
    Size,
)
from torch_geometric.utils import add_self_loops, remove_self_loops, softmax

#from ..inits import glorot, zeros
import torch
from torch import nn
import torch.nn.functional as F

from torch_geometric.nn import GCNConv


class Encoder(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, activation, base_model=GATConv, k: int = 2, skip=False,tau=0.8,num_hidden=256):
        super(Encoder, self).__init__()
        self.base_model = base_model
        self.tau=tau
        assert k >= 2
        self.k = k
        self.conv = [base_model(in_channels,  out_channels)]
        for _ in range(1, k - 1):
            self.conv.append(base_model( out_channels,  out_channels))
        self.conv.append(base_model( out_channels, out_channels))
        self.conv = nn.ModuleList(self.conv)
        self.num_hidden=num_hidden
        self.activation = activation

    def E_sim(self, z1: torch.Tensor, z2: torch.Tensor):
        z1 = F.normalize(z1)
        z2 = F.normalize(z2)
        return torch.mm(z1, z2.t())


    def E_semi_loss(self, z1: torch.Tensor, z2: torch.Tensor):
        f = lambda x: torch.exp(x / self.tau)
        between_sim = f(self.E_sim(z1, z2))
        return between_sim


    def forward(self, x_1: torch.Tensor, edge_index_1: torch.Tensor, x_2: torch.Tensor, edge_index_2: torch.Tensor):
        h_1 = torch.zeros(self.num_hidden).to("cuda:0")
        h_2 = torch.zeros(self.num_hidden).to("cuda:0")
        for i in range(self.k):
            x_1 = self.activation(self.conv[i](x_1, edge_index_1))
            x_2 = self.activation(self.conv[i](x_2, edge_index_2))
            attention=self.E_semi_loss(x_1,x_2)/ torch.sqrt(torch.tensor(x_1.shape[1]))
            attention = torch.trace(attention)/(torch.tensor(x_1.shape[1]))
            h_1 = h_1 +   x_1/(attention*(i+1))
            h_2 = h_2 +   x_2/(attention*(i+1))

        return h_1,h_2

def cos_sim(x1, x2, tau: float, norm):
    if norm:
        return F.softmax(x1 @ x2.T / tau, dim=1)
    else:
        return torch.exp(x1 @ x2.T / tau)

class GRACE(torch.nn.Module):
    def __init__(self, encoder: Encoder, num_hidden: int, num_proj_hidden: int, tau: float = 0.5,beta=1,lambdas=1,dataset='Cora',similarity='cos',num_community=7):
        super(GRACE, self).__init__()
        self.encoder: Encoder = encoder
        self.tau: float = tau
        self.fc1 = torch.nn.Linear(num_hidden, num_proj_hidden)
        self.fc2 = torch.nn.Linear(num_proj_hidden, num_hidden)
        self.num_hidden = num_hidden
        self.similarity=similarity
        self.num_community=num_community
        self.center = nn.Parameter(torch.randn(self.num_community, num_hidden, dtype=torch.float32))
        self.lambdas=lambdas
        self.dataset=dataset
        self.beta=beta
    def DeCA(self,R,edge_index):
        n = len(R)
        m = n*(n-1)

        # adjacent matrix
        A = torch.zeros(n,n,device=R.device,dtype=torch.float32)
        A[edge_index[0],edge_index[1]] = 1

        # edge density constraint
        DF = R.T@A@R
        # return (0.5*DF.sum()-(n-1+0.5)*DF.trace())/m+(R.T@R).trace()/n/2
        return (R.T@R).trace()/n/2-DF.trace()/n

    def RBF_sim(x1, x2, tau: float, norm: bool = False):
        xx1, xx2 = torch.stack(len(x2) * [x1]), torch.stack(len(x1) * [x2])
        sub = xx1.transpose(0, 1) - xx2
        R = (sub * sub).sum(dim=2)
        if norm:
            return F.softmax(-R / (tau * tau), dim=1)
        else:
            return torch.exp(-R / (tau * tau))



    def community_assign(self,h):
        if self.similarity=='cos':
            return cos_sim(h.detach(),F.normalize(self.center),self.tau,norm=True)
        return self.RBF_sim(h.detach(),F.normalize(self.center),self.tau,norm=True)

    def community_contrast(self,h1,h2,R1,R2):
        # gather communities
        index1, index2 = R1.detach().argmax(dim=1), R2.detach().argmax(dim=1)
        C1, C2 = [], []
        for i in range(self.num_community):
            h_c1, h_c2 = h1[index1 == i], h2[index2 == i]
            if h_c1.shape[0] > 0:
                C1.append(h_c1.sum(dim=0) / h_c1.shape[0])
            else:
                C1.append(torch.zeros(h1.shape[1], device=h1.device, dtype=torch.float32))
            if h_c2.shape[0] > 0:
                C2.append(h_c2.sum(dim=0) / h_c2.shape[0])
            else:
                C2.append(torch.zeros(h2.shape[1], device=h2.device, dtype=torch.float32))
        C1, C2 = torch.stack(C1), torch.stack(C2)
        s12 = cos_sim(C1, C2, self.tau, norm=False)
        s21 = s12

        # compute InfoNCE
        loss12 = -torch.log(s12.diag()) + torch.log(s12.sum(1))
        loss21 = -torch.log(s21.diag()) + torch.log(s21.sum(1))
        L_node = (loss12 + loss21) / 2
        return C1,C2,L_node.mean()



    def loss(self, z1, z2 ,mean=True, batch_size=None):
        b=mean
        h1 = self.projection(z1)
        h2 = self.projection(z2)
        if batch_size is None:
            l1 = self.semi_loss(h1, h2)
            l2 = self.semi_loss(h2, h1)
        else:
            l1 = self.batched_semi_loss(h1, h2, batch_size)
            l2 = self.batched_semi_loss(h2, h1, batch_size)

        ret = (l1 + l2) * 0.5
        ret = ret.mean() if mean else ret.sum()

        return ret

    def projection(self, z: torch.Tensor) -> torch.Tensor:
        z = F.elu(self.fc1(z))
        return self.fc2(z)

    def sim(self, z1: torch.Tensor, z2: torch.Tensor):
        z1 = F.normalize(z1)
        z2 = F.normalize(z2)
        return torch.mm(z1, z2.t())

    def semi_loss(self, z1: torch.Tensor, z2: torch.Tensor):
        f = lambda x: torch.exp(x / self.tau)
        # z1=z1[con]
        # z2=z2[con]
        refl_sim = f(self.sim(z1, z1))
        between_sim = f(self.sim(z1, z2))

        return -torch.log(between_sim.diag() / (refl_sim.sum(1) + between_sim.sum(1) - refl_sim.diag()))

    def batched_semi_loss(self, z1: torch.Tensor, z2: torch.Tensor, batch_size: int):
        # Space complexity: O(BN) (semi_loss: O(N^2))
        device = z1.device
        num_nodes = z1.size(0)
        num_batches = (num_nodes - 1) // batch_size + 1
        f = lambda x: torch.exp(x / self.tau)
        indices = torch.arange(0, num_nodes).to(device)
        losses = []

        for i in range(num_batches):
            mask = indices[i * batch_size:(i + 1) * batch_size]
            refl_sim = f(self.sim(z1[mask], z1))  # [B, N]
            between_sim = f(self.sim(z1[mask], z2))  # [B, N]

            losses.append(-torch.log(between_sim[:, i * batch_size:(i + 1) * batch_size].diag()
                                     / (refl_sim.sum(1) + between_sim.sum(1)
                                        - refl_sim[:, i * batch_size:(i + 1) * batch_size].diag())))

    def forward(self, x_1: torch.Tensor, edge_index_1: torch.Tensor,x_2: torch.Tensor, edge_index_2: torch.Tensor) -> torch.Tensor:
        h_1,h_2 = self.encoder(x_1, edge_index_1,x_2, edge_index_2)
        R1, R2 = self.community_assign(h_1), self.community_assign(h_2)
        DeCA = (self.DeCA(R1, edge_index_1) + self.DeCA(R2, edge_index_2)) / 2
        C1,C2,loss_3 =self.community_contrast(h_1,h_2,R1,R2)
        loss_2 = DeCA
        loss_1=self.loss(h_1,h_2,True,batch_size=64 if self.dataset == 'Coauthor-Phy' or self.dataset == 'ogbn-arxiv' else None)
        loss_3 = self.loss(C1,C2,True,None)
        loss = loss_1 + loss_2  * self.beta+ loss_3 * self.lambdas
        return h_1,h_2,loss



        # return torch.cat(losses)



def glorot(tensor):#inits.py中
    if tensor is not None:
        stdv = math.sqrt(6.0 / (tensor.size(-2) + tensor.size(-1)))
        tensor.data.uniform_(-stdv, stdv)#将tensor的值设置为-stdv, stdv之间
def zeros(tensor):
    if tensor is not None:
        tensor.data.fill_(0)






class LogReg(nn.Module):
    def __init__(self, ft_in, nb_classes):
        super(LogReg, self).__init__()
        self.fc = nn.Linear(ft_in, nb_classes)

        for m in self.modules():
            self.weights_init(m)

    def weights_init(self, m):
        if isinstance(m, nn.Linear):
            torch.nn.init.xavier_uniform_(m.weight.data)
            if m.bias is not None:
                m.bias.data.fill_(0.0)

    def forward(self, seq):
        ret = self.fc(seq)
        return ret
